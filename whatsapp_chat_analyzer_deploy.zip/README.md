# 💬 WhatsApp Chat Analyzer (Python)

A modern, fast, privacy-focused WhatsApp Chat Analyzer built in **Python** using **Streamlit** and **Plotly**. Conforms fully with the PRD, SRS, UI/UX Design Spec, and Architecture guidelines.

---

## 🌟 Key Features

- **🔒 100% Privacy-First**: All parsing and analytics run purely in memory on your local machine. No chat content is uploaded or stored anywhere.
- **📱 Multi-Platform Support**:
  - Android 12-hour and 24-hour formats
  - iOS bracket timestamps with narrow space normalization
  - `.txt` exports and direct `.zip` archive extraction
  - Multi-line message accumulation
  - System messages and `<Media omitted>` classification
- **📊 Interactive Dashboard**:
  - **Metric Cards**: Total Messages, Total Words, Media Shared, Links Shared, Days Covered, Avg Msgs/Day.
  - **Dynamic Participant Filter**: Filter by "Overall" or individual participants to recompute stats on the fly.
  - **Overview Tab**: Most active users (horizontal bar chart + percentage table), busiest day of week, busiest month.
  - **Timeline Tab**: Monthly timeline, Daily timeline, and 7×24 Weekday-by-Hour Activity Heatmap.
  - **Words Tab**: Word Cloud generation, Top 20 most frequent words, built-in **English** and **Roman Urdu / Hinglish** stop words with an exclusion toggle.
  - **Emojis Tab**: Top emojis share donut chart, comprehensive emoji frequency table (supports skin tones, flags, and ZWJ combinations).
  - **Insights Tab**: Conversation starters (first message after 6+ hr gap), Average reply time in minutes, Longest chat streak, and Top shared domains.
  - **Exporting**: Download CSV data and structured JSON reports.

---

## 🚀 Quick Start

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Launch the Web Application
```bash
streamlit run app.py
```
This opens the web interface in your browser (typically at `http://localhost:8501`).

### 3. Run Command-Line Analysis (CLI)
You can also analyze chat files directly in the terminal without opening a browser:
```bash
# Basic terminal output
python cli.py sample_chat_android.txt

# Filter by a participant and export results to JSON
python cli.py sample_chat_android.txt --user "Ali" --export-json output.json
```

---

## 🧪 Running Automated Tests
Run unit tests with `pytest`:
```bash
pytest tests/ -v
```

---

## 📁 Project Structure

```text
├── app.py                      # Streamlit interactive web application
├── cli.py                      # Command-line interface tool
├── requirements.txt            # Python dependencies
├── sample_chat_android.txt     # Sample Android export for testing
├── sample_chat_ios.txt         # Sample iOS export for testing
├── whatsapp_analyzer/          # Core domain package
│   ├── __init__.py             # Package exports
│   ├── models.py               # Message, ChatStats, ParseResult dataclasses
│   ├── cleaner.py              # Invisible character and space normalization
│   ├── parser.py               # Android, iOS, multi-line, zip parser
│   ├── extractors.py           # Links, domains, and complex emojis
│   ├── stopwords.py            # English and Roman Urdu stop words
│   └── analyzers.py            # Pure analytics engines (stats, timeline, words, emojis, insights)
└── tests/                      # Automated unit test suite
    ├── test_parser.py
    └── test_analyzers.py
```
