from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional

@dataclass
class Message:
    id: int
    datetime: datetime
    sender: str
    text: str
    is_media: bool = False
    media_type: Optional[str] = None  # "image", "video", "audio", "sticker", "document", "other"
    is_system: bool = False
    links: List[str] = field(default_factory=list)
    emojis: List[str] = field(default_factory=list)

    # Derived attributes computed once for fast filtering
    hour: int = 0
    weekday: int = 0  # 0=Monday, 6=Sunday
    weekday_name: str = ""
    month: int = 1
    month_name: str = ""
    year: int = 2000
    date_str: str = ""
    year_month: str = ""
    char_count: int = 0
    word_count: int = 0

    def __post_init__(self):
        if self.datetime:
            self.hour = self.datetime.hour
            self.weekday = self.datetime.weekday()
            self.weekday_name = self.datetime.strftime("%A")
            self.month = self.datetime.month
            self.month_name = self.datetime.strftime("%B")
            self.year = self.datetime.year
            self.date_str = self.datetime.strftime("%Y-%m-%d")
            self.year_month = self.datetime.strftime("%Y-%m")
        if self.text and not self.is_media and not self.is_system:
            self.char_count = len(self.text)
            self.word_count = len(self.text.split())

@dataclass
class ParseResult:
    status: str  # "ok", "ambiguous-date", "error"
    messages: List[Message] = field(default_factory=list)
    participants: List[str] = field(default_factory=list)
    sample: Optional[str] = None
    error_message: Optional[str] = None
    date_order: Optional[str] = None  # "DMY" or "MDY"
    platform: Optional[str] = None    # "android" or "ios"

@dataclass
class ChatStats:
    total_messages: int
    total_words: int
    media_count: int
    link_count: int
    start_date: Optional[datetime]
    end_date: Optional[datetime]
    total_days: int
    avg_messages_per_day: float
