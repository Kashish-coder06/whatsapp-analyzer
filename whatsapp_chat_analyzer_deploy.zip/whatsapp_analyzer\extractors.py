"""Extractors for links, domains, and complex emojis.

Supports skin tone modifiers, Zero Width Joiners (ZWJ), flags, and domain parsing.
"""

import re
from urllib.parse import urlparse
from typing import List, Tuple
import emoji

# Robust URL regex that captures http, https, and www links
URL_PATTERN = re.compile(
    r'(?:https?:\/\/|www\.)[^\s<>"]+[^\s<>".,;:\'\?!)]',
    re.IGNORECASE
)

def extract_urls(text: str) -> List[str]:
    """Extract all URLs from a text string."""
    if not text:
        return []
    urls = URL_PATTERN.findall(text)
    # Ensure all urls have a scheme for clean domain parsing
    normalized = []
    for u in urls:
        if not u.startswith("http://") and not u.startswith("https://"):
            normalized.append("http://" + u)
        else:
            normalized.append(u)
    return normalized

def extract_domains(urls: List[str]) -> List[str]:
    """Extract netloc/domain name from a list of URLs (e.g. youtube.com)."""
    domains = []
    for u in urls:
        try:
            parsed = urlparse(u)
            domain = parsed.netloc.lower()
            if domain.startswith("www."):
                domain = domain[4:]
            if domain:
                domains.append(domain)
        except Exception:
            continue
    return domains

def extract_emojis(text: str) -> List[str]:
    """Extract all emojis from text, preserving ZWJ, skin tones, and flag sequences."""
    if not text:
        return []
    
    # Use emoji library's emoji_list which accurately handles compound emojis and variants
    try:
        found = emoji.emoji_list(text)
        return [item['emoji'] for item in found]
    except Exception:
        # Fallback to regex if emoji library encounters unexpected token
        import regex
        # Unicode 15.1 compliant emoji pattern
        emoji_pattern = regex.compile(r'\X', regex.UNICODE)
        return [c for c in emoji_pattern.findall(text) if any(char in emoji.EMOJI_DATA for char in c)]
