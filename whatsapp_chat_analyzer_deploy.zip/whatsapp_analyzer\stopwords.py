"""Stop word dictionaries for English and Roman Urdu / Hinglish.

Meets PRD 6.5 and SRS FR-27 requirements for text analysis and word cloud.
"""

ENGLISH_STOPWORDS = {
    "a", "about", "above", "after", "again", "against", "all", "am", "an", "and",
    "any", "are", "aren't", "as", "at", "be", "because", "been", "before", "being",
    "below", "between", "both", "but", "by", "can't", "cannot", "could", "couldn't",
    "did", "didn't", "do", "does", "doesn't", "doing", "don't", "down", "during",
    "each", "few", "for", "from", "further", "had", "hadn't", "has", "hasn't",
    "have", "haven't", "having", "he", "he'd", "he'll", "he's", "her", "here",
    "here's", "hers", "herself", "him", "himself", "his", "how", "how's", "i",
    "i'd", "i'll", "i'm", "i've", "if", "in", "into", "is", "isn't", "it",
    "it's", "its", "itself", "let's", "me", "more", "most", "mustn't", "my",
    "myself", "no", "nor", "not", "of", "off", "on", "once", "only", "or",
    "other", "ought", "our", "ours", "ourselves", "out", "over", "own", "same",
    "shan't", "she", "she'd", "she'll", "she's", "should", "shouldn't", "so",
    "some", "such", "than", "that", "that's", "the", "their", "theirs", "them",
    "themselves", "then", "there", "there's", "these", "they", "they'd", "they'll",
    "they're", "they've", "this", "those", "through", "to", "too", "under",
    "until", "up", "very", "was", "wasn't", "we", "we'd", "we'll", "we're",
    "we've", "were", "weren't", "what", "what's", "when", "when's", "where",
    "where's", "which", "while", "who", "who's", "whom", "why", "why's", "with",
    "won't", "would", "wouldn't", "you", "you'd", "you'll", "you're", "you've",
    "your", "yours", "yourself", "yourselves", "ok", "okay", "yeah", "yes", "no",
    "bro", "sir", "mam", "pls", "please", "thanks", "thank", "thx"
}

ROMAN_URDU_STOPWORDS = {
    # Pronouns & pointers
    "mai", "main", "me", "mera", "meri", "mere", "mujhe", "mujh",
    "tum", "tumhe", "tumhari", "tumhara", "tumhare", "tu", "tujhe", "tera", "teri", "tere",
    "aap", "ap", "aapka", "aapki", "aapke", "apka", "apki", "apke", "unka", "unki", "unke",
    "yeh", "ye", "woh", "wo", "is", "us", "in", "un", "isse", "usse", "inka", "inka",
    # Helping verbs / verbs
    "hai", "hain", "ho", "hoon", "hun", "tha", "thi", "the", "thay",
    "hoga", "hogi", "honge", "hota", "hoti", "hote", "hua", "hui", "hue", "huye",
    "kar", "karo", "karna", "karni", "karne", "karta", "karti", "karte", "kiya", "kiye", "kya",
    "raha", "rahi", "rahe", "gaya", "gayi", "gaye", "aaya", "aayi", "aaye", "aana", "jana",
    # Prepositions, conjunctions, particles
    "ka", "ki", "ke", "ko", "se", "mein", "me", "pe", "par", "pa", "tak", "saath",
    "aur", "ya", "lekin", "magar", "per", "bhi", "hi", "to", "tou", "toh", "so",
    "ne", "na", "nahi", "nahin", "nhi", "mat",
    # Question & common filler words
    "kya", "kyun", "kyu", "kab", "kahan", "kidhar", "kaise", "kese", "kitna", "kitni", "kitne",
    "kaun", "kon", "kisko", "kis",
    "acha", "achha", "accha", "theek", "thik", "sahi", "haan", "han", "hnn", "hmm", "hm",
    "bhai", "yaar", "yr", "yar", "ab", "jab", "tab", "phir", "fir", "baad", "pehle",
    "kuch", "kuchh", "koi", "sab", "bohot", "boht", "bahut", "zyada", "ziada", "kam",
    "bas", "sirf", "batao", "bata", "dekh", "dekho", "sun", "suno", "chalo", "chlo"
}

# WhatsApp specific omitted text and noise words
MEDIA_NOISE_WORDS = {
    "media", "omitted", "image", "video", "audio", "document", "sticker",
    "contact", "card", "location", "live", "deleted", "message", "call", "voice"
}

ALL_STOPWORDS = ENGLISH_STOPWORDS.union(ROMAN_URDU_STOPWORDS).union(MEDIA_NOISE_WORDS)
