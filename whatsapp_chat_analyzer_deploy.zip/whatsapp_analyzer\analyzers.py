"""Analyzers for WhatsApp chat messages.

Provides:
- StatsCalculator
- UserAnalyzer
- TimelineAnalyzer
- WordAnalyzer
- EmojiAnalyzer
- InsightAnalyzer
- MediaAnalyzer
- SearchAnalyzer
- SentimentAnalyzer
- ComparisonAnalyzer
- Composite analyze_chat function
"""

import re
from collections import Counter, defaultdict
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional, Tuple

import pandas as pd

from .models import Message, ChatStats
from .stopwords import ALL_STOPWORDS, MEDIA_NOISE_WORDS
from .extractors import extract_domains

class StatsCalculator:
    @staticmethod
    def calculate(messages: List[Message], user: str = "Overall") -> ChatStats:
        """Calculate primary top-level statistics for the selected participant."""
        filtered = [
            m for m in messages
            if not m.is_system and (user == "Overall" or m.sender == user)
        ]
        
        if not filtered:
            return ChatStats(
                total_messages=0,
                total_words=0,
                media_count=0,
                link_count=0,
                start_date=None,
                end_date=None,
                total_days=0,
                avg_messages_per_day=0.0
            )
            
        total_messages = len(filtered)
        total_words = sum(
            m.word_count for m in filtered if not m.is_media
        )
        
        media_count = sum(1 for m in filtered if m.is_media)
        link_count = sum(len(m.links) for m in filtered)
        
        sorted_dates = sorted(m.datetime for m in filtered)
        start_date = sorted_dates[0]
        end_date = sorted_dates[-1]
        
        total_days = max((end_date.date() - start_date.date()).days + 1, 1)
        avg_messages_per_day = round(total_messages / total_days, 1)
        
        return ChatStats(
            total_messages=total_messages,
            total_words=total_words,
            media_count=media_count,
            link_count=link_count,
            start_date=start_date,
            end_date=end_date,
            total_days=total_days,
            avg_messages_per_day=avg_messages_per_day
        )

class UserAnalyzer:
    @staticmethod
    def rank_participants(messages: List[Message]) -> pd.DataFrame:
        """Rank participants by message count, word count, avg length, and percentage share."""
        user_msgs = [m for m in messages if not m.is_system]
        if not user_msgs:
            return pd.DataFrame(columns=["User", "Messages", "Words", "Media", "Avg Words/Msg", "Percentage"])
            
        total_count = len(user_msgs)
        user_counts = Counter(m.sender for m in user_msgs)
        user_words = defaultdict(int)
        user_media = defaultdict(int)
        user_text_msgs = defaultdict(int)
        
        for m in user_msgs:
            if not m.is_media:
                user_words[m.sender] += m.word_count
                user_text_msgs[m.sender] += 1
            else:
                user_media[m.sender] += 1
                
        rows = []
        for sender, count in user_counts.most_common():
            pct = round((count / total_count) * 100, 1)
            text_count = user_text_msgs[sender]
            avg_words = round(user_words[sender] / max(text_count, 1), 1)
            rows.append({
                "User": sender,
                "Messages": count,
                "Words": user_words[sender],
                "Media": user_media[sender],
                "Avg Words/Msg": avg_words,
                "Percentage": pct
            })
            
        return pd.DataFrame(rows)

    @staticmethod
    def get_participant_details(messages: List[Message], user: str) -> Dict[str, Any]:
        """Deep dive metrics for a single participant."""
        user_msgs = [m for m in messages if not m.is_system and m.sender == user]
        if not user_msgs:
            return {}
            
        total_msgs = len(user_msgs)
        text_msgs = [m for m in user_msgs if not m.is_media]
        total_words = sum(m.word_count for m in text_msgs)
        total_chars = sum(m.char_count for m in text_msgs)
        media_count = sum(1 for m in user_msgs if m.is_media)
        links_count = sum(len(m.links) for m in user_msgs)
        
        avg_words = round(total_words / max(len(text_msgs), 1), 1)
        avg_chars = round(total_chars / max(len(text_msgs), 1), 1)
        
        hour_counts = Counter(m.hour for m in user_msgs)
        top_hour = hour_counts.most_common(1)[0][0] if hour_counts else 0
        top_hour_str = f"{top_hour:02d}:00 - {(top_hour+1)%24:02d}:00"
        
        day_counts = Counter(m.weekday_name for m in user_msgs)
        top_day = day_counts.most_common(1)[0][0] if day_counts else "N/A"
        
        return {
            "total_messages": total_msgs,
            "total_words": total_words,
            "avg_words_per_msg": avg_words,
            "avg_chars_per_msg": avg_chars,
            "media_count": media_count,
            "links_count": links_count,
            "most_active_hour": top_hour_str,
            "most_active_day": top_day
        }

class ComparisonAnalyzer:
    @staticmethod
    def compare_two_users(messages: List[Message], user1: str, user2: str) -> Dict[str, Any]:
        """Head-to-head comparison between two participants."""
        u1_details = UserAnalyzer.get_participant_details(messages, user1)
        u2_details = UserAnalyzer.get_participant_details(messages, user2)
        
        # Calculate reply times between user1 and user2
        user_msgs = [m for m in messages if not m.is_system and m.sender in [user1, user2]]
        u1_replies = []
        u2_replies = []
        max_delta = timedelta(hours=12)
        
        for i in range(1, len(user_msgs)):
            prev_m = user_msgs[i - 1]
            curr_m = user_msgs[i]
            if curr_m.sender != prev_m.sender:
                diff = curr_m.datetime - prev_m.datetime
                if timedelta(seconds=0) < diff <= max_delta:
                    mins = diff.total_seconds() / 60.0
                    if curr_m.sender == user1:
                        u1_replies.append(mins)
                    else:
                        u2_replies.append(mins)
                        
        u1_avg_reply = round(sum(u1_replies) / len(u1_replies), 1) if u1_replies else None
        u2_avg_reply = round(sum(u2_replies) / len(u2_replies), 1) if u2_replies else None
        
        return {
            "user1": user1,
            "user2": user2,
            "user1_stats": {**u1_details, "avg_reply_mins": u1_avg_reply},
            "user2_stats": {**u2_details, "avg_reply_mins": u2_avg_reply}
        }

class TimelineAnalyzer:
    WEEKDAYS_ORDER = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    MONTHS_ORDER = [
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    ]
    
    @staticmethod
    def get_monthly_timeline(messages: List[Message], user: str = "Overall") -> pd.DataFrame:
        filtered = [m for m in messages if not m.is_system and (user == "Overall" or m.sender == user)]
        if not filtered:
            return pd.DataFrame(columns=["YearMonth", "MonthYear", "Messages"])
            
        counts = Counter(m.datetime.strftime("%Y-%m") for m in filtered)
        sorted_keys = sorted(counts.keys())
        
        data = []
        for ym in sorted_keys:
            dt = datetime.strptime(ym, "%Y-%m")
            label = dt.strftime("%b %Y")
            data.append({"YearMonth": ym, "MonthYear": label, "Messages": counts[ym]})
            
        return pd.DataFrame(data)

    @staticmethod
    def get_daily_timeline(messages: List[Message], user: str = "Overall") -> pd.DataFrame:
        filtered = [m for m in messages if not m.is_system and (user == "Overall" or m.sender == user)]
        if not filtered:
            return pd.DataFrame(columns=["Date", "Messages"])
            
        counts = Counter(m.date_str for m in filtered)
        sorted_keys = sorted(counts.keys())
        return pd.DataFrame([{"Date": d, "Messages": counts[d]} for d in sorted_keys])

    @staticmethod
    def get_hourly_timeline(messages: List[Message], user: str = "Overall") -> pd.DataFrame:
        filtered = [m for m in messages if not m.is_system and (user == "Overall" or m.sender == user)]
        counts = Counter(m.hour for m in filtered)
        data = [{"Hour": f"{h:02d}:00", "Messages": counts.get(h, 0)} for h in range(24)]
        return pd.DataFrame(data)

    @staticmethod
    def get_weekday_distribution(messages: List[Message], user: str = "Overall") -> pd.DataFrame:
        filtered = [m for m in messages if not m.is_system and (user == "Overall" or m.sender == user)]
        counts = Counter(m.weekday_name for m in filtered)
        data = [
            {"Weekday": day, "Messages": counts.get(day, 0)}
            for day in TimelineAnalyzer.WEEKDAYS_ORDER
        ]
        return pd.DataFrame(data)

    @staticmethod
    def get_month_distribution(messages: List[Message], user: str = "Overall") -> pd.DataFrame:
        filtered = [m for m in messages if not m.is_system and (user == "Overall" or m.sender == user)]
        counts = Counter(m.month_name for m in filtered)
        data = [
            {"Month": m, "Messages": counts.get(m, 0)}
            for m in TimelineAnalyzer.MONTHS_ORDER
        ]
        return pd.DataFrame(data)

    @staticmethod
    def get_activity_heatmap(messages: List[Message], user: str = "Overall") -> pd.DataFrame:
        filtered = [m for m in messages if not m.is_system and (user == "Overall" or m.sender == user)]
        matrix = {day: [0] * 24 for day in TimelineAnalyzer.WEEKDAYS_ORDER}
        for m in filtered:
            if m.weekday_name in matrix and 0 <= m.hour < 24:
                matrix[m.weekday_name][m.hour] += 1
        df = pd.DataFrame(matrix).T
        df.columns = [f"{h:02d}:00" for h in range(24)]
        return df

class WordAnalyzer:
    CLEAN_WORD_RE = re.compile(r"^[^\w]+|[^\w]+$", re.UNICODE)
    
    @staticmethod
    def get_word_frequencies(
        messages: List[Message],
        user: str = "Overall",
        remove_stopwords: bool = True,
        top_n: int = 50
    ) -> List[Tuple[str, int]]:
        filtered = [
            m for m in messages
            if not m.is_system and not m.is_media and (user == "Overall" or m.sender == user)
        ]
        
        counter = Counter()
        for m in filtered:
            text_without_urls = re.sub(r'https?://\S+|www\.\S+', '', m.text)
            tokens = text_without_urls.split()
            for token in tokens:
                word = WordAnalyzer.CLEAN_WORD_RE.sub("", token).lower()
                if len(word) < 2 or word.isdigit():
                    continue
                if remove_stopwords and word in ALL_STOPWORDS:
                    continue
                counter[word] += 1
                
        return counter.most_common(top_n)

class EmojiAnalyzer:
    @staticmethod
    def get_emoji_frequencies(messages: List[Message], user: str = "Overall", top_n: int = 25) -> pd.DataFrame:
        filtered = [m for m in messages if not m.is_system and (user == "Overall" or m.sender == user)]
        counter = Counter()
        for m in filtered:
            for em in m.emojis:
                counter[em] += 1
                
        total_emojis = sum(counter.values())
        if total_emojis == 0:
            return pd.DataFrame(columns=["Emoji", "Count", "Percentage"])
            
        rows = []
        for em, count in counter.most_common(top_n):
            rows.append({
                "Emoji": em,
                "Count": count,
                "Percentage": round((count / total_emojis) * 100, 1)
            })
            
        return pd.DataFrame(rows)

class SentimentAnalyzer:
    """Fast rule-based sentiment classifier for English and Roman Urdu / Hinglish messages."""
    POSITIVE_WORDS = {
        "good", "great", "awesome", "nice", "excellent", "super", "happy", "love", "thanks", "thank",
        "perfect", "amazing", "best", "zabardast", "behtareen", "shukriya", "mubarak", "acha", "accha",
        "sahi", "theek", "khushi", "congrats", "congratulations", "welcome", "yay", "wow", "yes", "superb"
    }
    NEGATIVE_WORDS = {
        "bad", "sad", "sorry", "hate", "terrible", "worst", "angry", "problem", "issue", "error",
        "fail", "failed", "late", "bura", "kharab", "masla", "pareshan", "ghalat", "nhi", "nahi",
        "difficult", "tension", "loss", "gussa", "bekaar", "bakwaas", "afsos", "fault"
    }
    
    @staticmethod
    def analyze_sentiments(messages: List[Message], user: str = "Overall") -> Dict[str, Any]:
        filtered = [m for m in messages if not m.is_system and not m.is_media and (user == "Overall" or m.sender == user)]
        if not filtered:
            return {"positive": 0, "neutral": 0, "negative": 0, "pos_pct": 0, "neu_pct": 100, "neg_pct": 0}
            
        pos = 0
        neg = 0
        neu = 0
        
        for m in filtered:
            words = set(re.findall(r'\b\w+\b', m.text.lower()))
            pos_score = len(words.intersection(SentimentAnalyzer.POSITIVE_WORDS))
            neg_score = len(words.intersection(SentimentAnalyzer.NEGATIVE_WORDS))
            
            # Emoji sentiment boosters
            for em in m.emojis:
                if em in ["❤️", "😊", "👍", "👍🏽", "🎉", "🔥", "✨", "🙌", "🥳", "☕"]:
                    pos_score += 1
                elif em in ["😢", "😭", "💔", "😡", "😞", "👎"]:
                    neg_score += 1
                    
            if pos_score > neg_score:
                pos += 1
            elif neg_score > pos_score:
                neg += 1
            else:
                neu += 1
                
        total = len(filtered)
        return {
            "positive": pos,
            "neutral": neu,
            "negative": neg,
            "total_evaluated": total,
            "pos_pct": round((pos / total) * 100, 1),
            "neu_pct": round((neu / total) * 100, 1),
            "neg_pct": round((neg / total) * 100, 1)
        }

class MediaAnalyzer:
    @staticmethod
    def get_media_breakdown(messages: List[Message], user: str = "Overall") -> pd.DataFrame:
        filtered = [m for m in messages if not m.is_system and (user == "Overall" or m.sender == user)]
        media_msgs = [m for m in filtered if m.is_media]
        
        counter = Counter()
        for m in media_msgs:
            t = m.media_type or "Media"
            counter[t] += 1
            
        if not counter:
            return pd.DataFrame(columns=["Media Type", "Count", "Percentage"])
            
        total = sum(counter.values())
        rows = [
            {"Media Type": m_type, "Count": c, "Percentage": round((c / total) * 100, 1)}
            for m_type, c in counter.most_common()
        ]
        return pd.DataFrame(rows)

class SearchAnalyzer:
    @staticmethod
    def search_messages(
        messages: List[Message],
        query: str = "",
        user: str = "Overall",
        date_start: Optional[datetime] = None,
        date_end: Optional[datetime] = None
    ) -> List[Message]:
        results = []
        q_lower = query.strip().lower()
        
        for m in messages:
            if m.is_system:
                continue
            if user != "Overall" and m.sender != user:
                continue
            if date_start and m.datetime.date() < date_start.date():
                continue
            if date_end and m.datetime.date() > date_end.date():
                continue
            if q_lower and q_lower not in m.text.lower():
                continue
            results.append(m)
            
        return results

class InsightAnalyzer:
    @staticmethod
    def get_conversation_starters(messages: List[Message], gap_hours: float = 6.0) -> pd.DataFrame:
        user_msgs = [m for m in messages if not m.is_system]
        if not user_msgs:
            return pd.DataFrame(columns=["User", "Starts", "Percentage"])
            
        starters = Counter()
        gap_delta = timedelta(hours=gap_hours)
        starters[user_msgs[0].sender] += 1
        
        for i in range(1, len(user_msgs)):
            prev_m = user_msgs[i - 1]
            curr_m = user_msgs[i]
            if curr_m.datetime - prev_m.datetime >= gap_delta:
                starters[curr_m.sender] += 1
                
        total_starts = sum(starters.values())
        rows = []
        for sender, count in starters.most_common():
            rows.append({
                "User": sender,
                "Starts": count,
                "Percentage": round((count / total_starts) * 100, 1) if total_starts else 0
            })
            
        return pd.DataFrame(rows)

    @staticmethod
    def get_average_reply_time(messages: List[Message], max_reply_hours: float = 12.0) -> pd.DataFrame:
        user_msgs = [m for m in messages if not m.is_system]
        if len(user_msgs) < 2:
            return pd.DataFrame(columns=["User", "Average Reply Time (mins)", "Replies Count"])
            
        reply_times = defaultdict(list)
        max_delta = timedelta(hours=max_reply_hours)
        
        for i in range(1, len(user_msgs)):
            prev_m = user_msgs[i - 1]
            curr_m = user_msgs[i]
            
            if curr_m.sender != prev_m.sender:
                diff = curr_m.datetime - prev_m.datetime
                if timedelta(seconds=0) < diff <= max_delta:
                    minutes = diff.total_seconds() / 60.0
                    reply_times[curr_m.sender].append(minutes)
                    
        rows = []
        for sender, times in reply_times.items():
            if times:
                avg_time = round(sum(times) / len(times), 1)
                rows.append({
                    "User": sender,
                    "Average Reply Time (mins)": avg_time,
                    "Replies Count": len(times)
                })
                
        df = pd.DataFrame(rows)
        if not df.empty:
            df = df.sort_values(by="Average Reply Time (mins)")
        return df

    @staticmethod
    def get_longest_streak(messages: List[Message]) -> int:
        user_msgs = [m for m in messages if not m.is_system]
        if not user_msgs:
            return 0
            
        unique_days = sorted(list(set(m.datetime.date() for m in user_msgs)))
        if not unique_days:
            return 0
            
        longest = 1
        current = 1
        
        for i in range(1, len(unique_days)):
            if unique_days[i] == unique_days[i - 1] + timedelta(days=1):
                current += 1
                if current > longest:
                    longest = current
            else:
                current = 1
                
        return longest

    @staticmethod
    def get_top_domains(messages: List[Message], user: str = "Overall", top_n: int = 15) -> pd.DataFrame:
        filtered = [m for m in messages if not m.is_system and (user == "Overall" or m.sender == user)]
        all_links = []
        for m in filtered:
            all_links.extend(m.links)
            
        domains = extract_domains(all_links)
        counter = Counter(domains)
        
        if not counter:
            return pd.DataFrame(columns=["Domain", "Count"])
            
        rows = [{"Domain": d, "Count": c} for d, c in counter.most_common(top_n)]
        return pd.DataFrame(rows)

def analyze_chat(messages: List[Message], user: str = "Overall", remove_stopwords: bool = True) -> Dict[str, Any]:
    """Convenience pipeline executing all analyzers for a given user filter."""
    return {
        "stats": StatsCalculator.calculate(messages, user),
        "user_ranks": UserAnalyzer.rank_participants(messages),
        "monthly_timeline": TimelineAnalyzer.get_monthly_timeline(messages, user),
        "daily_timeline": TimelineAnalyzer.get_daily_timeline(messages, user),
        "hourly_timeline": TimelineAnalyzer.get_hourly_timeline(messages, user),
        "weekday_dist": TimelineAnalyzer.get_weekday_distribution(messages, user),
        "month_dist": TimelineAnalyzer.get_month_distribution(messages, user),
        "heatmap": TimelineAnalyzer.get_activity_heatmap(messages, user),
        "words": WordAnalyzer.get_word_frequencies(messages, user, remove_stopwords=remove_stopwords),
        "emojis": EmojiAnalyzer.get_emoji_frequencies(messages, user),
        "media_breakdown": MediaAnalyzer.get_media_breakdown(messages, user),
        "sentiments": SentimentAnalyzer.analyze_sentiments(messages, user),
        "starters": InsightAnalyzer.get_conversation_starters(messages),
        "reply_times": InsightAnalyzer.get_average_reply_time(messages),
        "longest_streak": InsightAnalyzer.get_longest_streak(messages),
        "top_domains": InsightAnalyzer.get_top_domains(messages, user)
    }
