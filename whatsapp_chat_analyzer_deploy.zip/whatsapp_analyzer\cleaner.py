"""Text cleaning utility for WhatsApp chat exports.

Handles invisible characters, narrow no-break spaces, and byte-order marks
that commonly appear in Android and iOS exports.
"""

import re

# Invisible Unicode characters often injected by WhatsApp/mobile OS
INVISIBLE_CHARS = [
    "\u200e",  # Left-to-Right Mark (LRM)
    "\u200f",  # Right-to-Left Mark (RLM)
    "\ufeff",  # Zero-width no-break space / BOM
    "\u200b",  # Zero-width space
    "\u200c",  # Zero-width non-joiner (unless in script text, handled safely)
    "\u200d",  # Zero-width joiner in isolation
    "\u2060",  # Word joiner
]

# Non-standard spaces to normalize to standard ASCII space
SPACE_NORMALIZATION = {
    "\u202f": " ",  # Narrow no-break space (standard in iOS AM/PM timestamps)
    "\u00a0": " ",  # Non-breaking space
    "\u2009": " ",  # Thin space
    "\u2008": " ",  # Punctuation space
    "\u2002": " ",  # En space
    "\u2003": " ",  # Em space
}

def clean_text(raw_text: str) -> str:
    """Clean exported WhatsApp chat text.
    
    1. Normalizes newlines (\r\n -> \n)
    2. Strips BOM and leading/trailing invisible control marks
    3. Normalizes narrow non-breaking spaces
    """
    if not raw_text:
        return ""
    
    # Normalize newlines
    text = raw_text.replace("\r\n", "\n").replace("\r", "\n")
    
    # Replace non-standard spaces
    for weird_space, normal_space in SPACE_NORMALIZATION.items():
        text = text.replace(weird_space, normal_space)
        
    # Remove invisible directional and zero-width markers
    for char in ["\u200e", "\u200f", "\ufeff", "\u2060"]:
        text = text.replace(char, "")
        
    return text
