"""Parser module for WhatsApp chat exports.

Supports:
- Android formats (12h, 24h, seconds optional, dashes)
- iOS formats (12h, 24h, square brackets, narrow spaces)
- Multi-line messages
- Date order heuristics (DD/MM vs MM/DD) with fallback
- System message separation
- Media placeholder detection with categorization (image, video, audio, sticker, doc)
- Direct .zip file extraction
"""

import io
import re
import zipfile
from datetime import datetime
from typing import List, Optional, Tuple, Dict, Any

from .models import Message, ParseResult
from .cleaner import clean_text
from .extractors import extract_urls, extract_emojis

# Detailed media classifications
MEDIA_TYPE_MAP = [
    (re.compile(r"image\s+omitted|photo\s+omitted", re.IGNORECASE), "Image"),
    (re.compile(r"video\s+omitted", re.IGNORECASE), "Video"),
    (re.compile(r"audio\s+omitted|voice\s+message\s+omitted", re.IGNORECASE), "Audio"),
    (re.compile(r"sticker\s+omitted", re.IGNORECASE), "Sticker"),
    (re.compile(r"document\s+omitted", re.IGNORECASE), "Document"),
    (re.compile(r"gif\s+omitted", re.IGNORECASE), "GIF"),
    (re.compile(r"contact\s+card\s+omitted", re.IGNORECASE), "Contact"),
    (re.compile(r"<\s*media\s+omitted\s*>", re.IGNORECASE), "Media"),
]

# Patterns for message lines
ANDROID_LINE_PATTERN = re.compile(
    r"^(\d{1,4}[/\-.]\d{1,2}[/\-.]\d{2,4}),?\s+(\d{1,2}:\d{2}(?::\d{2})?(?:\s*[a-zA-Z]{2})?)\s*-\s*(.*)$"
)

IOS_LINE_PATTERN = re.compile(
    r"^\[(\d{1,4}[/\-.]\d{1,2}[/\-.]\d{2,4}),?\s+(\d{1,2}:\d{2}(?::\d{2})?(?:\s*[a-zA-Z]{2})?)\]\s*(.*)$"
)

def get_media_type(text: str) -> Optional[str]:
    """Check if message is media placeholder and return category."""
    clean = text.strip()
    for pattern, m_type in MEDIA_TYPE_MAP:
        if pattern.search(clean):
            return m_type
    if clean.lower() == "null":
        return "Media"
    return None

def is_media_message(text: str) -> bool:
    return get_media_type(text) is not None

def detect_platform(raw_text: str) -> str:
    """Detect whether file originates from Android or iOS based on headers."""
    cleaned = clean_text(raw_text[:10000])
    lines = cleaned.split("\n")
    for line in lines:
        line = line.strip()
        if not line:
            continue
        if IOS_LINE_PATTERN.match(line):
            return "ios"
        if ANDROID_LINE_PATTERN.match(line):
            return "android"
    return "android"

def detect_date_order(raw_dates: List[str]) -> str:
    """Determine whether dates are DD/MM or MM/DD by inspecting numbers > 12."""
    has_first_gt_12 = False
    has_second_gt_12 = False
    
    for date_str in raw_dates:
        parts = re.split(r"[/\-.]", date_str.strip())
        if len(parts) >= 2:
            try:
                p1 = int(parts[0])
                p2 = int(parts[1])
                if p1 > 12:
                    has_first_gt_12 = True
                if p2 > 12:
                    has_second_gt_12 = True
            except ValueError:
                continue
                
    if has_first_gt_12 and not has_second_gt_12:
        return "DMY"
    elif has_second_gt_12 and not has_first_gt_12:
        return "MDY"
    if raw_dates and len(re.split(r"[/\-.]", raw_dates[0])) >= 3:
        if len(re.split(r"[/\-.]", raw_dates[0])[0]) == 4:
            return "YMD"
            
    return "AMBIGUOUS"

def parse_datetime(date_str: str, time_str: str, date_order: str) -> Optional[datetime]:
    """Parse date and time parts into datetime object."""
    t_clean = time_str.strip().upper()
    parts = re.split(r"[/\-.]", date_str.strip())
    if len(parts) != 3:
        return None
    
    try:
        if date_order == "MDY":
            month, day, year = int(parts[0]), int(parts[1]), int(parts[2])
        elif date_order == "YMD":
            year, month, day = int(parts[0]), int(parts[1]), int(parts[2])
        else:  # Default to DMY
            day, month, year = int(parts[0]), int(parts[1]), int(parts[2])
            
        if year < 100:
            year += 2000
            
        is_pm = "PM" in t_clean
        is_am = "AM" in t_clean
        time_digits = re.sub(r"[^\d:]", "", t_clean)
        time_parts = [int(p) for p in time_digits.split(":") if p]
        
        hour = time_parts[0]
        minute = time_parts[1] if len(time_parts) > 1 else 0
        second = time_parts[2] if len(time_parts) > 2 else 0
        
        if is_pm and hour < 12:
            hour += 12
        elif is_am and hour == 12:
            hour = 0
            
        return datetime(year, month, day, hour, minute, second)
    except Exception:
        return None

def parse_chat(raw_text: str, override_date_order: Optional[str] = None) -> ParseResult:
    """Parse WhatsApp exported chat content into structured messages."""
    if not raw_text or not raw_text.strip():
        return ParseResult(
            status="error",
            error_message="The chat file is empty."
        )
        
    cleaned_text = clean_text(raw_text)
    lines = cleaned_text.split("\n")
    
    parsed_lines = []
    collected_dates = []
    platform = None
    
    for line in lines:
        if not line.strip():
            continue
            
        m_ios = IOS_LINE_PATTERN.match(line)
        m_and = ANDROID_LINE_PATTERN.match(line)
        
        if m_ios:
            if platform is None:
                platform = "ios"
            d_str, t_str, rest = m_ios.groups()
            parsed_lines.append((d_str, t_str, rest, False))
            collected_dates.append(d_str)
        elif m_and:
            if platform is None:
                platform = "android"
            d_str, t_str, rest = m_and.groups()
            parsed_lines.append((d_str, t_str, rest, False))
            collected_dates.append(d_str)
        else:
            if parsed_lines:
                last_d, last_t, last_rest, last_is_cont = parsed_lines[-1]
                parsed_lines[-1] = (last_d, last_t, last_rest + "\n" + line, last_is_cont)
                
    if not parsed_lines:
        return ParseResult(
            status="error",
            error_message="We couldn't find any WhatsApp messages in this file. Please ensure it is an exported WhatsApp .txt file."
        )
        
    detected_order = detect_date_order(collected_dates)
    effective_order = override_date_order or detected_order
    final_date_order = "DMY" if effective_order in ["AMBIGUOUS", "DMY", None] else effective_order
    
    messages: List[Message] = []
    participants_set = set()
    msg_id = 1
    
    for d_str, t_str, rest, _ in parsed_lines:
        dt = parse_datetime(d_str, t_str, final_date_order)
        if not dt:
            continue
            
        if ":" in rest:
            sender, text = rest.split(":", 1)
            sender = sender.strip()
            text = text.strip()
            is_system = False
            if "Messages and calls are end-to-end encrypted" in sender:
                is_system = True
                sender = "System"
                text = rest.strip()
            else:
                participants_set.add(sender)
        else:
            sender = "System"
            text = rest.strip()
            is_system = True
            
        m_type = get_media_type(text)
        is_media = m_type is not None
        links = extract_urls(text)
        emojis = extract_emojis(text)
        
        msg = Message(
            id=msg_id,
            datetime=dt,
            sender=sender,
            text=text,
            is_media=is_media,
            media_type=m_type,
            is_system=is_system,
            links=links,
            emojis=emojis
        )
        messages.append(msg)
        msg_id += 1
        
    if not messages:
        return ParseResult(
            status="error",
            error_message="Could not parse any valid message timestamps."
        )
        
    participants = sorted(list(participants_set))
    status = "ambiguous-date" if (detected_order == "AMBIGUOUS" and override_date_order is None) else "ok"
    
    return ParseResult(
        status=status,
        messages=messages,
        participants=participants,
        sample=lines[0] if lines else "",
        date_order=final_date_order,
        platform=platform or "android"
    )

def parse_chat_file(file_bytes_or_str: Any, filename: str = "", override_date_order: Optional[str] = None) -> ParseResult:
    """Parse a chat from raw bytes, string, or uploaded file object (including .zip)."""
    if filename.lower().endswith(".zip") or (isinstance(file_bytes_or_str, (bytes, bytearray)) and file_bytes_or_str.startswith(b"PK")):
        try:
            if isinstance(file_bytes_or_str, (bytes, bytearray)):
                z_stream = io.BytesIO(file_bytes_or_str)
            else:
                z_stream = file_bytes_or_str
                
            with zipfile.ZipFile(z_stream) as z:
                txt_files = [f for f in z.namelist() if f.lower().endswith(".txt")]
                if not txt_files:
                    return ParseResult(status="error", error_message="No .txt file found inside the zip archive.")
                with z.open(txt_files[0]) as f:
                    raw_content = f.read().decode("utf-8", errors="replace")
                    return parse_chat(raw_content, override_date_order=override_date_order)
        except Exception as e:
            return ParseResult(status="error", error_message=f"Failed to read zip archive: {str(e)}")
            
    if isinstance(file_bytes_or_str, bytes):
        raw_content = file_bytes_or_str.decode("utf-8", errors="replace")
    elif hasattr(file_bytes_or_str, "read"):
        content = file_bytes_or_str.read()
        if isinstance(content, bytes):
            raw_content = content.decode("utf-8", errors="replace")
        else:
            raw_content = str(content)
    else:
        raw_content = str(file_bytes_or_str)
        
    return parse_chat(raw_content, override_date_order=override_date_order)
